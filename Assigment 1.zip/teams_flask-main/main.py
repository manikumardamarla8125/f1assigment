from flask import Flask, request, render_template, redirect, url_for, session
import firebase_admin
from firebase_admin import credentials, auth, firestore, storage
import datetime

cred = credentials.Certificate("firebase-credentials.json")

firebase_admin.initialize_app(cred,{'storageBucket': 'formula-1-4c34a.appspot.com'})
db = firestore.client()

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'


@app.route('/admin', methods=['GET'])
def home():
    user = session.get('user')
    if user:
        teams = db.collection('teams').get()

        # Get the download URL of the user's profile picture
        blob = storage.bucket().blob(f"profile_pictures/{user}.png")
        profile_pic_url = blob.generate_signed_url(
            datetime.timedelta(seconds=300), method='GET')

        return render_template('dashboard.html',
                               user=user,
                               teams=teams,
                               profile_pic_url=profile_pic_url)
    else:
        return redirect(url_for('login'))
    
@app.route('/', methods=['GET'])
def publicHome():
    user = session.get('user')

    if user:
        return redirect(url_for('home'))
   
    return render_template('public_home.html' )




@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        # Get the uploaded file from the form
        picture = request.files['picture']

        try:
            # Create the user in Firebase Authentication
            user = auth.create_user(email=email, password=password)

            # Upload the picture to Firebase Storage
            bucket = storage.bucket()
            blob = bucket.blob(
                f"profile_pictures/{email}.png"
            )  # modify the name of the file to be the same as the user's email address
            blob.upload_from_file(
                picture,
                content_type='image/png'  # Set the content type header
            )

            session['user'] = user.email
            return redirect(url_for('home'))
        except auth.EmailAlreadyExistsError:
            return render_template('signup.html',
                                   error='Email address is already in use')
    else:
        return render_template('signup.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        try:
            user = auth.get_user_by_email(email)
            print(user.uid)
            # auth.verify_password(password, user.password)
            session['user'] = user.email
            return redirect(url_for('home'))
        except auth.InvalidIdTokenError:
            return render_template('login.html',
                                   error='Invalid email or password')
    else:
        return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('publicHome'))


@app.route('/teams', methods=['GET'])
def teams():
    user = session.get('user')

    if user:
        teams = db.collection('teams').get()

        return render_template('teams.html', teams=teams, user=user)
    else:
        return redirect(url_for('login'))


@app.route('/addteams', methods=['GET'])
def AddTeams():
    user = session.get('user')

    if user:
        return render_template('add_teams.html')
    else:
        return redirect(url_for('login'))


@app.route('/updateteams/<team_id>', methods=['GET'])
def updateTeams(team_id):
    user = session.get('user')
    if user:
        teamToUpdate = db.collection('teams').document(team_id)
        teams = teamToUpdate.get()

        if teams:
            return render_template('update_teams.html',
                                   user=user,
                                   teams=teams.to_dict(),
                                   teams_id=teams.id)
        else:
            return "Team not found"
    else:
        return redirect(url_for('login'))


@app.route('/teams/create', methods=['POST'])
def create_team():
    team_name = request.form['team_name']
    founded = int(request.form['founded'])
    poles = int(request.form['poles'])
    wins = int(request.form['wins'])
    constructors_titles = int(request.form['constructors_titles'])
    last_season_position = int(request.form['last_season_position'])

    db.collection('teams').add({
        'team_name': team_name,
        'founded': founded,
        'poles': poles,
        'wins': wins,
        'constructors_titles': constructors_titles,
        'last_season_position': last_season_position
    })
    return redirect(url_for('teams'))


@app.route('/teams/<team_id>/update', methods=['POST'])
def update_team(team_id):
    team_ref = db.collection('teams').document(team_id)
    team_name = request.form['team_name']
    founded = request.form['founded']
    poles = request.form['poles']
    wins = request.form['wins']
    constructors_titles = request.form['constructors_titles']
    last_season_position = request.form['last_season_position']

    team_ref.update({
        'team_name': team_name,
        'founded': founded,
        'poles': poles,
        'wins': wins,
        'constructors_titles': constructors_titles,
        'last_season_position': last_season_position
    })
    return redirect(url_for('teams'))


@app.route('/teams/<team_id>/delete', methods=['POST'])
def delete_team(team_id):
    db.collection('teams').document(team_id).delete()
    return redirect(url_for('teams'))


@app.route('/drivers', methods=['GET'])
def driver():
    user = session.get('user')

    if user:
        drivers = db.collection('drivers').get()

        return render_template('driver.html', drivers=drivers, user=user)
    else:
        return redirect(url_for('login'))


# Add new Driver
@app.route('/drivers/new', methods=['GET', 'POST'])
def new_driver():
    user = session.get('user')

    if request.method == 'POST':
        driver = {
            'name': request.form['name'],
            'age': int(request.form['age']),
            'total_pole_positions': int(request.form['total_pole_positions']),
            'total_race_wins': int(request.form['total_race_wins']),
            'total_points_scored': int(request.form['total_points_scored']),
            'total_world_titles': int(request.form['total_world_titles']),
            'total_fastest_laps': int(request.form['total_fastest_laps']),
            'team': request.form['team']
        }
        drivers_ref = db.collection('drivers')
        drivers_ref.add(driver)
        return redirect(url_for('driver'))

    return render_template('add_driver.html', user=user)

# Update Driver
@app.route('/drivers/<id>/edit', methods=['GET', 'POST'])
def edit_driver(id):
    user = session.get('user')

    driver_ref = db.collection('drivers').document(id)
    driver = driver_ref.get()
    print(driver.to_dict().get('total_points_scored'))
    if request.method == 'POST':
        driver_ref.update({
            'name':
            request.form['name'],
            'age':
            int(request.form['age']),
            'total_pole_positions':
            int(request.form['total_pole_positions']),
            'total_race_wins':
            int(request.form['total_race_wins']),
            'total_points_scored':
            int(request.form['total_points_scored']),
            'total_world_titles':
            int(request.form['total_world_titles']),
            'total_fastest_laps':
            int(request.form['total_fastest_laps']),
            'team':
            request.form['team']
        })
        return redirect(url_for('driver'))

    return render_template('update_driver.html', driver=driver, user=user)

# Delete Driver
@app.route('/drivers/<id>/delete', methods=['POST'])
def delete_driver(id):
    db.collection('drivers').document(id).delete()
    return redirect(url_for('driver'))

@app.route('/search', methods=['GET', 'POST'])
def search():
    teams = []
    error = ""
    drivers = []
    if request.method == 'POST':
        search_type = request.form['search_type']
        print(f"Search Type {search_type}")
        if search_type == 'driver':
            age = request.form['age']
            total_pole_positions = request.form['total_pole_positions']
            total_race_wins = request.form['total_race_wins']
            drivers = db.collection('drivers').where('age', '==', int(age)).where('total_pole_positions', '==', int(total_pole_positions)).where('total_race_wins', '==', int(total_race_wins)).get()
            if len(drivers) == 0:
                error = "no result found..."
            return render_template('search_results.html', results=drivers, error=error , search_type=search_type)
        elif search_type == 'team':
            founded = request.form['founded']
            poles = request.form['poles']
            wins = request.form['wins']

            teams = db.collection('teams').where('founded', '==', founded).where('poles', '==', poles).where('wins', '==', wins).get()
            print(f"Teams Data: ", teams)
            if len(teams) == 0:
                error = "no result found..."

            return render_template('search_results.html', results=teams, search_type=search_type , error=error)
    else:
        return render_template('forbidden.html')


@app.route('/driver/<driver_id>')
def onlyDriver(driver_id):

    driver_ref = db.collection('drivers').document(driver_id)
    driver = driver_ref.get().to_dict()

    return render_template('only_driver.html', driver=driver)

@app.route('/team/<team_id>')
def onlyTeam(team_id):
    team_ref = db.collection('teams').document(team_id)
    team = team_ref.get().to_dict()
    return render_template('only_team.html', team=team)

@app.route('/compare/driver', methods=['GET', 'POST'])
def compareDriver():
    drivers = db.collection('drivers').stream()

    driver_names = [doc.to_dict()['name'] for doc in drivers]
    print(driver_names)
    if request.method == 'POST':
        driver1_name = request.form.get('driver1')
        driver2_name = request.form.get('driver2')
        driver1 = db.collection('drivers').where('name', '==', driver1_name).get()[0].to_dict()
        print("driver1==>>",driver1)
        driver2 = db.collection('drivers').where('name', '==', driver2_name).get()[0].to_dict()
        print("driver2==>>",driver2)
        return render_template('compare_driver.html', driver1=driver1, driver2=driver2)
    return render_template('select_drivers.html', driver_names=driver_names)

@app.route('/compare/teams', methods=['GET', 'POST'])
def compareTeams():
    teams = db.collection('teams').stream()

    teams_names = [doc.to_dict()['team_name'] for doc in teams]
    print(teams_names)
    if request.method == 'POST':
        team1_name = request.form.get('team1')
        team2_name = request.form.get('team2')
        team1 = db.collection('teams').where('team_name', '==', team1_name).get()[0].to_dict()
        print(team1)
        team2 = db.collection('teams').where('team_name', '==', team2_name).get()[0].to_dict()
        print(team2)
        return render_template('compare_team.html', team1=team1, team2=team2)
    return render_template('select_teams.html', teams_names=teams_names)



if __name__ == '__main__':
    app.run(port=8000, debug=True)
